from django.db import models
from allauth.account.signals import user_signed_up
from django.dispatch import receiver
from cslabman.models import Students
from django.db.models.signals import post_save
from django.contrib.auth.models import User, Group

# user.email -> returns the user's email as a string
# user.password -> returns the user's password

@receiver(user_signed_up)
def after_user_signed_up(request, user, **kwargs):
	# Domain checker using allauth signals
	if user.email.endswith('mtmail.mtsu.edu'):
		pass

	elif user.email.endswith('mtsu.edu'):
		pass

	else:
		user.is_active = False
		#student = Students.objects.create(pipeline_id = user.username)
		#student.save()
		user.save()


#when a new user is added, add them to the students database
@receiver(post_save,  sender=User)
def init_new_student(instance, created, raw, **kwargs):
	# raw is set when model is created from loaddata.
	if created and not raw:

		studentUsername = instance.username
		Students.objects.create( pipeline_id= studentUsername)


	
