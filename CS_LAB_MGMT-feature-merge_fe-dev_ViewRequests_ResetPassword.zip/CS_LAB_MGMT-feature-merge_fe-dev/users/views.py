import datetime
import this

from django.shortcuts import render, redirect
from .forms import registerForm
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from .forms import requestForm
from cslabman.models import AccountRequests
from .forms import passwordResetForm

# Create your views here.

#View when users try to register for website

def register(request):

    if request.method == 'POST':

        form = registerForm(request.POST)

        if form.is_valid():

            return redirect('Request-home')

    else:

        form = registerForm().as_p()

    return render(request, 'users/login.html', {'form': form})

#After login, take to access request questionnaire form, must be logged in to view
@login_required
def mtcsRequests(request):

    if request.method == 'POST':

        form = requestForm(request.POST, initial={'pipeline_id': request.user})


        if form.is_valid():
            form.save()
            messages.success(request, f'Request Saved')
            return redirect('Request-Home')
    else:

        form = requestForm().as_p()
    return render(request, 'users/mtcsRequests.html',  {'form': form})


#After login, can reset passwords as needed
@login_required
def resetPassword(request):
    if request.method == 'POST':
        #create request form using logged in user, and password reset value of 4
        form = passwordResetForm(request.POST, initial={'pipeline_id': request.user,})
        #PASSWORDS MATCH
        if form.is_valid():

            form.save()
            messages.success(request, f'Password Reset Request Saved')
            return redirect('Request-Home')

    else:
        form = passwordResetForm().as_p()

    return render(request, 'users/resetPassword.html', {'form': form})

# After login, view current requests of this user
@login_required
def viewRequests(request):

    #get current requests, filter by current user
    stuRequests = AccountRequests.objects.filter(pipeline_id=request.user.username)

    students = {
        "students": stuRequests
    }

    return render(request, 'users/viewRequests.html',  students, )