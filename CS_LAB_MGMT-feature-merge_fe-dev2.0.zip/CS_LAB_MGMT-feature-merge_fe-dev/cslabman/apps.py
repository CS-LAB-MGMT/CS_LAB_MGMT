from django.apps import AppConfig


class CslabmanConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'cslabman'
