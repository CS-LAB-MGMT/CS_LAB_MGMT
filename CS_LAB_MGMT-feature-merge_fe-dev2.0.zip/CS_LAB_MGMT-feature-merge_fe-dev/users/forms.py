import datetime
from django.contrib.auth.models import User
from django.forms import ModelForm
from django import forms
from cslabman.models import AccountRequests
from cslabman.models import Students
from cslabman.models import Systems
from django.db import models


class registerForm(forms.Form):
    Pipeline_ID = forms.CharField(label="Pipeline_ID", min_length=6, required=True)
    Pipeline_Password = forms.CharField(label="Pipeline_Password", widget=forms.PasswordInput, required=True)





class requestForm(ModelForm):


    #django specs require html select values to be specified in this format
    REQUESTCHOICES = [(1, 'Request a new account'),
                      (3, 'Request special permissions'),
                      (4, 'Reset Password')]


    #specify the order in which rom fields show up on webpage
    field_order = ['system_name', 'request_type', 'reason']


    #declare form fields with some styling and labels

    request_type = forms.TypedChoiceField(choices=REQUESTCHOICES, widget=forms.RadioSelect, label='What is this request for?',
                                   required=True, coerce=int)


    system_name = forms.ModelChoiceField(queryset=Systems.objects.all().order_by('system_name'), widget=forms.Select,
                                         label='What system is this request for?', required=True,
                                         to_field_name='system_name')

    reason = forms.CharField(required=False, label='Reason for Request:',
                             widget=forms.Textarea(attrs={'style': 'width:100%;'}))

    pipeline_id = forms.ModelChoiceField(required=False,queryset=Students.objects.all().order_by('pipeline_id'),
                              disabled=True, widget=forms.HiddenInput())

    #Declare what model form is based on
    class Meta:
        model = AccountRequests
        fields = ['request_type', 'system_name',  'reason', 'pipeline_id']







