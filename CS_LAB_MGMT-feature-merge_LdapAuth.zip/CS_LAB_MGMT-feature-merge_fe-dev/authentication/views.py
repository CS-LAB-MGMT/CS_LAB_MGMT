from django.shortcuts import render
from authentication.forms import CustomSignupForm
from django.shortcuts import render, redirect

"""
#extend django allauth custom signup view
def register_user(request):

    if request.method == 'POST':

        form = CustomSignupForm(request.POST)

        if form.is_valid():

            return redirect('account_email_verification_sent')

    else:

        form = CustomSignupForm().as_p()

    return render(request, 'authentication/register.html', {'form': form})

#Directs users to email confirmation. Go to MTMAIL to confirm registration
def confirm_email(request):
    return render(request, 'authentication/confirm-email.html')

"""


