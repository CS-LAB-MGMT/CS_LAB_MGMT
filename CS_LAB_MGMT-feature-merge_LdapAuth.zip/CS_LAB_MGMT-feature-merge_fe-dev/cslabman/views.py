# import statements

from django.shortcuts import render
from django.http import HttpResponse

# Shows home page. Takes HTML template from Templates directory home.html
def home (request):
    return render(request, 'cslabman/home.html')

#Shows help page, takes HTML template from Templates directory help.html
def help(request):
    return render(request, 'cslabman/help.html')




